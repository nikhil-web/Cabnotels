<?php
include('session.php');
if($_SESSION['auth'] == false){
    navigate("index.php");
}
        $output = '';
        $count = 0;
        $sql = 'SELECT * FROM cart INNER JOIN users on cart.user_id = cart.user_id ORDER BY cart.id DESC';
        $result = mysqli_query($db, $sql);
              if (mysqli_num_rows($result) > 0) {
                  // output data of each row
                  while($row= mysqli_fetch_assoc($result)) {
                  $count++;
                  if ($row["status"] == 1) {
                    $output .= '<tr style="background-color:#28a745;">
                      <td>'.$count.'</td>
                      <td>'.$row["id"].'</td>
                      <td>'.$row["first_name"].'</td>
                      <td>'.$row["last_name"].'</td>
                      <td>'.$row["user_phone"].'</td>
                      <td>'.$row["user_email"].'</td>
                      <td>'.$row["item_price"].'</td>
                      </tr>';
                  }else {
                    $output .= '<tr style="background-color:#dc3545">
                      <td>'.$count.'</td>
                      <td>'.$count.'</td>
                      <td>'.$row["id"].'</td>
                      <td>'.$row["first_name"].'</td>
                      <td>'.$row["last_name"].'</td>
                      <td>'.$row["user_phone"].'</td>
                      <td>'.$row["user_email"].'</td>
                      <td>'.$row["item_price"].'</td>
                      </tr>';
                  }

                    }
                  }
	      echo json_encode($output);
        mysqli_close($db);
