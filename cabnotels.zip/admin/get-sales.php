<?php
include('session.php');
if($_SESSION['auth'] == false){
    navigate("index.php");
}
        $output = '';
        $count = 0;
        $sql = 'SELECT * FROM cart INNER JOIN users on cart.user_id = cart.user_id ORDER BY cart.id DESC';
        $result = mysqli_query($db, $sql);
              if (mysqli_num_rows($result) > 0) {
                  // output data of each row
                  while($row= mysqli_fetch_assoc($result)) {
                  $count++;
                  if ($row["status"] == 1) {
                    $output .= '<tr style="background-color:#28a745;">
                      <td>'.$count.'</td>
                      <td>'.$row["id"].'</td>
                      <td>'.$row["first_name"].'</td>
                      <td>'.$row["last_name"].'</td>
                      <td>'.$row["user_phone"].'</td>
                      <td>'.$row["user_email"].'</td>
                      <td>'.$row["item_price"].'</td>
                      <td>

                              <button style="width: 100%;margin:1px;" class="btn btn-info btn-sm edit btn-flat"  data-toggle="modal" data-target="#sales_id_finish_'.$row["id"].'"><i class="fa fa-eye"></i> View</button>

                      </td>
                      <td>
                              <button style="width: 100%;margin:1px;" class="btn btn-danger btn-sm edit btn-flat" data-toggle="modal" data-target="#update_order_status_'.$row["id"].'"><i class="fa fa-eye"></i> Edit</button>

                          </td>
                      </tr>';
                  }else {
                    $output .= '<tr style="background-color:#dc3545">
                      <td>'.$count.'</td>
                      <td>'.$count.'</td>
                      <td>'.$row["id"].'</td>
                      <td>'.$row["first_name"].'</td>
                      <td>'.$row["last_name"].'</td>
                      <td>'.$row["user_phone"].'</td>
                      <td>'.$row["user_email"].'</td>
                      <td>'.$row["item_price"].'</td>
                      <td>

                              <button style="width: 100%;margin:1px;" class="btn btn-info btn-sm edit btn-flat"  data-toggle="modal" data-target="#sales_id_finish_'.$row["id"].'"><i class="fa fa-eye"></i> View</button>

                      </td>
                      <td>
                              <button style="width: 100%;margin:1px;" class="btn btn-danger btn-sm edit btn-flat" data-toggle="modal" data-target="#update_order_status_'.$row["id"].'"><i class="fa fa-eye"></i> Edit</button>

                          </td>
                      </tr>';
                  }

                    }
                  }
	      echo json_encode($output);
        mysqli_close($db);
