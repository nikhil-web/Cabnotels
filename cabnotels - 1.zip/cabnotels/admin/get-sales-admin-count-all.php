<?php
include('session.php');
if($_SESSION['auth'] == false){
    navigate("index.php");
}
        $output = '';
        $count = 0;
        $sql = 'SELECT * FROM cart INNER JOIN users on cart.user_id = users.user_id';
        $result = mysqli_query($db, $sql);
        $output =mysqli_num_rows($result);
	      echo json_encode($output);
        mysqli_close($db);
