<?php
if($_SESSION['auth'] != true){
  navigate("index.php?error=login");
}
else{

}
