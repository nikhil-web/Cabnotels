<!-- Sidebar -->
<ul class="sidebar navbar-nav toggled">

  <li id="home" class="nav-item">
    <a class="nav-link" href="admin.php">
      <i class="fas fa-fw fa-tachometer-alt"></i>
      <span>Home</span>
    </a>
  </li>

  <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-folder"></i>
            <span>Appearance</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(5px, 63px, 0px);">
            <h6 class="dropdown-header">Appearance</h6>

            <a class="dropdown-item" href="frontpage.php">
              <i class="fas fa-envelope-open-text"></i>
              <span>Frontpage</span>
            </a>

            <a class="dropdown-item" href="contact.php">
              <i class="fas fa-envelope-open-text"></i>
              <span>Contact</span>
            </a>

              <a class="dropdown-item" href="about.php">
                <i class="fas fa-info-circle"></i>
                <span>About</span>
              </a>
          </div>
        </li>

  <li id="Sales" class="nav-item">
    <a class="nav-link" href="sales.php">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Sales</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="users.php">
      <i class="fas fa-users"></i>
      <span>Users</span></a>
  </li>

<li id="locations" class="nav-item">
    <a class="nav-link" href="locations.php">
    <i class="fas fa-thumbtack"></i>
      <span>locations</span></a>
  </li>
  <li id="Restaurants" class="nav-item">
    <a class="nav-link" href="hotels.php">
    <i class="fas fa-hotel"></i>
      <span>Hotels</span></a>
  </li>

  <li id="Sales" class="nav-item">
    <a class="nav-link" href="tours.php">
      <i class="fas fa-fw fa-chart-area"></i>
      <span>Tours</span></a>
  </li>

  <li id="Sales" class="nav-item">
    <a class="nav-link" href="taxi.php">
    <i class="fas fa-car"></i>
      <span>Taxi</span></a>
  </li>

  <li class="nav-item">

  </li>
  <li class="nav-item">

  </li>



</ul>
